using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomCoin : MonoBehaviour
{
    public int positionX = 0;
    public int positionZ = 0;

    // Start is called before the first frame update

    void Start()
    {
    positionX = Random.Range(-25,50);
    positionZ = Random.Range(-25,50);
    transform.position =new Vector3(positionX,5,positionZ);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
