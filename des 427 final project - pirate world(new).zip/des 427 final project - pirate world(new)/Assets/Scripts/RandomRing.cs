using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomRing : MonoBehaviour
{
     public int positionX;

    // Start is called before the first frame update
    void Start()
    {
    positionX = Random.Range(-25,25);
    transform.position =new Vector3(positionX,2,0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
